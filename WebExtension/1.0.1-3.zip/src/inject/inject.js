var extensionContainerId = "recipeSageBrowserExtensionRootContainer";
if (!document.getElementById(extensionContainerId)) {

  console.log("Loading RecipeSage Browser Extension");

  let container, currentSnip = {}, isDirty = false, imageURLInput;

  let fetchToken = (callback) => {
    chrome.storage.local.get(['token'], function (result) {
      callback(result.token);
    });
  }

  let setField = (field, val) => {
    currentSnip[field] = val;
    isDirty = true;
  }

  let snip = (field) => {
    var selectedText = window.getSelection().toString();
    setField(field, selectedText);
    return selectedText;
  }

  let hide = () => {
    isDirty = false;
    if (container) container.style.display = 'none';
  };

  let show = () => {
    if (!container) init();
    // Wait for DOM paint
    setTimeout(() => {
      container.style.display = 'block';
    });
  };

  let moveTo = (top, left) => {
    if (left < 0) {
      container.style.left = '0px';
    } else if ((left + container.offsetWidth) > window.innerWidth) {
      container.style.left = `${window.innerWidth - container.offsetWidth}px`;
    } else {
      container.style.left = `${left}px`;
    }

    if (top < 0) {
      container.style.top = '0px';
    } else if ((top + container.offsetHeight) > window.innerHeight) {
      container.style.top = `${window.innerHeight - container.offsetHeight}px`;
    } else {
      container.style.top = `${top}px`;
    }
  }

  let pos = {};
  let moveDrag = e => {
    let diffX = e.clientX - pos.lastX;
    let diffY = e.clientY - pos.lastY;

    moveTo(container.offsetTop + diffY, container.offsetLeft + diffX);

    pos.lastX = e.clientX;
    pos.lastY = e.clientY;
  }

  let stopDrag = () => {
    window.removeEventListener('mouseup', stopDrag);
    window.removeEventListener('mousemove', moveDrag);
  }

  let startDrag = e => {
    window.addEventListener('mouseup', stopDrag);
    window.addEventListener('mousemove', moveDrag);
    pos.lastX = e.clientX;
    pos.lastY = e.clientY;
  }

  let init = () => {
    let shadowRootContainer = document.createElement('div')
    shadowRootContainer.id = extensionContainerId;
    let shadowRoot = shadowRootContainer.attachShadow({ mode: 'closed' })
    document.body.appendChild(shadowRootContainer);

    let styles = document.createElement('link');
    styles.href = chrome.extension.getURL('./src/inject/clipTool.css');
    styles.rel = 'stylesheet';
    styles.type = 'text/css';
    shadowRoot.appendChild(styles);


    let ionIcons = document.createElement('link');
    ionIcons.href = 'https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css';
    ionIcons.rel = 'stylesheet';
    ionIcons.type = 'text/css';
    document.head.appendChild(ionIcons);
    shadowRoot.appendChild(ionIcons.cloneNode());

    container = document.createElement('div')
    container.className = 'rs-chrome-container';
    container.style.display = 'none';
    container.onmousedown = startDrag;
    window.onresize = () => moveTo(container.offsetTop, container.offsetLeft);
    shadowRoot.appendChild(container);

    let headline = document.createElement('div');
    headline.className = 'headline';
    container.appendChild(headline);

    let leftHeadline = document.createElement('div');
    leftHeadline.className = 'headline-left';
    headline.appendChild(leftHeadline);

    let moveButton = document.createElement('i');
    moveButton.className = 'icon ion-md-move';
    leftHeadline.appendChild(moveButton);

    let logoLink = document.createElement('a');
    logoLink.href = 'https://recipesage.com';
    logoLink.onmousedown = e => e.stopPropagation();
    leftHeadline.appendChild(logoLink);

    let logo = document.createElement('img');
    logo.src = chrome.extension.getURL('./images/recipesage-black-trimmed.png');
    logo.className = 'logo';
    logo.draggable = false;
    logoLink.appendChild(logo);

    let closeButton = document.createElement('button');
    closeButton.innerText = 'CLOSE';
    closeButton.onclick = hide;
    closeButton.onmousedown = e => e.stopPropagation();
    closeButton.className = 'close clear';
    headline.appendChild(closeButton);

    let tipContainer = document.createElement('div');
    tipContainer.className = 'tip';
    tipContainer.onmousedown = e => e.stopPropagation();
    container.appendChild(tipContainer);

    let tipText = document.createElement('a');
    tipText.innerText = "Open Tutorial";
    tipText.href = "https://recipesage.com/#/tips-tricks-tutorials";
    tipText.target = "_blank";
    tipContainer.appendChild(tipText);

    imageURLInput = createSnipper('Image URL', 'imageURL', false, "", true).input;
    createSnipper('Title', 'title');
    createSnipper('Description', 'description');
    createSnipper('Yield', 'yield');
    createSnipper('Active Time', 'activeTime');
    createSnipper('Total Time', 'totalTime');
    createSnipper('Source', 'source');
    createSnipper('Source URL', 'sourceURL', false, window.location.href, true);
    createSnipper('Ingredients', 'ingredients', true);
    createSnipper('Instructions', 'instructions', true);
    createSnipper('Notes', 'notes', true);

    let save = document.createElement('button');
    save.innerText = "Save";
    save.onclick = submit;
    save.onmousedown = e => e.stopPropagation();
    save.className = 'save';
    container.appendChild(save);

    window.addEventListener("beforeunload", function (e) {
      if (!isDirty) return undefined;

      var confirmationMessage = `You've made changes in the RecipeSage editor.
      If you leave before saving, your changes will be lost.`;

      (e || window.event).returnValue = confirmationMessage; //Gecko + IE
      return confirmationMessage; //Gecko + Webkit, Safari, Chrome etc.
    });
  }

  let createSnipper = (title, field, isTextArea, initialValue, disableSnip) => {
    let label = document.createElement('label');
    label.onmousedown = e => e.stopPropagation();
    container.appendChild(label);

    if (!disableSnip) {
      let button = document.createElement('button');
      button.className = 'icon-button';
      button.onclick = () => {
        input.value = snip(field);
      };
      label.appendChild(button);

      let buttonIcon = document.createElement('i');
      buttonIcon.className = 'icon ion-md-cut';
      button.appendChild(buttonIcon);
    }

    let input = document.createElement(isTextArea ? 'textarea' : 'input');
    input.placeholder = title;
    if (initialValue) input.value = initialValue;
    input.onchange = () => { setField(field, input.value) };
    label.appendChild(input);

    return { input: input, label: label };
  }

  chrome.runtime.onMessage.addListener(function(request, sender) {
    if (request.action === "show") show();
    if (request.action === "hide") hide();
    if (request.action === "snipImage") {
      show();
      imageURLInput.value = request.event.srcUrl
      setField('imageURL', request.event.srcUrl);
    }
  });

  // =========== Alerts ============

  let alertContainer;
  let initAlert = () => {
    let shadowRootContainer = document.createElement('div')
    let shadowRoot = shadowRootContainer.attachShadow({ mode: 'closed' })
    document.body.appendChild(shadowRootContainer);

    let alertStyles = document.createElement('link');
    alertStyles.href = chrome.extension.getURL('./src/inject/alert.css');
    alertStyles.rel = 'stylesheet';
    alertStyles.type = 'text/css';
    shadowRoot.appendChild(alertStyles);

    alertContainer = document.createElement('div');
    alertContainer.className = 'alert'
    shadowRoot.appendChild(alertContainer);
  }

  let alertTimeout;
  let displayAlert = (title, body, hideAfter, bodyLink) => {
    if (!alertContainer) initAlert();

    let headline = document.createElement('div');
    headline.className = "headline";
    alertContainer.appendChild(headline);

    let alertImg = document.createElement('img');
    alertImg.src = chrome.extension.getURL('./icons/android-chrome-512x512.png');
    headline.appendChild(alertImg);

    let alertTitle = document.createElement('h3');
    alertTitle.innerText = title;
    headline.appendChild(alertTitle);

    let alertBody = document.createElement('span');
    if (!bodyLink) {
      alertBody.innerText = body;
    } else {
      let alertBodyLink = document.createElement('a');
      alertBodyLink.target = "_blank";
      alertBodyLink.href = bodyLink;
      alertBodyLink.innerText = body;
      alertBody.appendChild(alertBodyLink);
    }
    alertContainer.appendChild(alertBody);

    // Wait for DOM paint
    setTimeout(() => {
      alertContainer.style.display = 'block';

      if (alertTimeout) clearTimeout(alertTimeout);
      alertTimeout = setTimeout(() => {
        alertContainer.style.display = 'none';
      }, hideAfter || 6000);
    });
  }

  let submit = () => {
    fetchToken(token => {
      return fetch(`https://recipesage.com/api/recipes?token=${token}`, {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        headers: {
          "Content-Type": "application/json",
        },
        referrer: "no-referrer",
        body: JSON.stringify(currentSnip)
      }).then(response => {
        if (response.ok) {
          response.json().then(data => {
            hide();
            displayAlert(
              `Recipe Saved!`,
              `Click to open`,
              4000,
              `https://recipesage.com/#/recipe/${data.id}`
            );
          });
        } else {
          switch (response.status) {
            case 401:
              chrome.storage.local.set({ token: null }, () => {
                displayAlert(
                  'Please Login',
                  `It looks like you're logged out. Please click the RecipeSage icon to login again.`,
                  4000
                );
              });
              break;
            case 412:
              displayAlert(
                `Could Not Save Recipe`,
                `A recipe title is required.`,
                4000
              );
              break;
            default:
              displayAlert(
                'Could Not Save Recipe',
                'An error occurred while saving the recipe. Please try again.',
                4000
              );
              break;
          }
        }
      }).catch(e => {
        displayAlert(
          'Could Not Save Recipe',
          'An error occurred while saving the recipe. Please try again.',
          4000
        );
      });
    });
  }
}
